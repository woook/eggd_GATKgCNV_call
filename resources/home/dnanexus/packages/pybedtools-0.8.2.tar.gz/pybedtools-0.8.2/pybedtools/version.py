
# THIS FILE IS GENERATED FROM SETUP.PY
version = '0.8.2'
__version__ = version